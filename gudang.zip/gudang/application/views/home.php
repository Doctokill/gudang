<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Home Page</title>
</head>
<body>
    <h1>Category List</h1>
    <table border="1">
        <tr>
            <td>ID</td>
            <td>Name</td>
            <td></td>
        </tr>
        <tr>
            <td>1</td>
            <td>makanan</td>
            <td><a href="">Update</a>  <a href="">Delete</a></td>
        </tr>
    </table>
    <a href="">Add Data Category</a>
</body>
</html>